define("Form1", function() {
    return function(controller) {
        function addWidgetsForm1() {
            this.setDefaultUnit(kony.flex.DP);
            var Label0e973a819789b45 = new kony.ui.Label({
                "id": "Label0e973a819789b45",
                "isVisible": true,
                "left": "850dp",
                "skin": "CopysknLblSectionHeader1",
                "text": "Label",
                "top": "210dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0d688e8f0c1a94c = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0d688e8f0c1a94c",
                "isVisible": true,
                "left": "416dp",
                "onClick": controller.AS_Button_e0a09fadf0e84f1f854c5ebf77746c95,
                "skin": "defBtnNormal",
                "text": "Login1",
                "top": "210dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0e4a36fcaddfd48 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0e4a36fcaddfd48",
                "isVisible": true,
                "left": "417dp",
                "onClick": controller.AS_Button_g2e107dd7e1647d3876fc90635b03233,
                "skin": "defBtnNormal",
                "text": "Login2",
                "top": "316dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Label0cb353593559b48 = new kony.ui.Label({
                "id": "Label0cb353593559b48",
                "isVisible": true,
                "left": "850dp",
                "skin": "defLabel",
                "text": "Label",
                "top": "329dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0a3b2dbc6055d49 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0a3b2dbc6055d49",
                "isVisible": true,
                "left": "424dp",
                "onClick": controller.AS_Button_af90f9b4bff548dfba0bb24eec9b13bf,
                "skin": "defBtnNormal",
                "text": "Login3",
                "top": "420dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Label0aec01eec02244c = new kony.ui.Label({
                "id": "Label0aec01eec02244c",
                "isVisible": true,
                "left": "855dp",
                "skin": "defLabel",
                "text": "Label",
                "top": "429dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Label0bab1d9bfe02345 = new kony.ui.Label({
                "id": "Label0bab1d9bfe02345",
                "isVisible": true,
                "left": "466dp",
                "skin": "CopydefLabel0gaea88e1172c41",
                "text": "Sample Login ",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(Label0e973a819789b45, Button0d688e8f0c1a94c, Button0e4a36fcaddfd48, Label0cb353593559b48, Button0a3b2dbc6055d49, Label0aec01eec02244c, Label0bab1d9bfe02345);
        };
        return [{
            "addWidgets": addWidgetsForm1,
            "enabledForIdleTimeout": false,
            "id": "Form1",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "CopyslForm0bdfea9d54c224c",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "demo1"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});