define("userForm1Controller", {
    //Type your controller code here 
    init: function() {
        this.view.Label0e973a819789b45.text = "success";
    },
    validate: function() {
        var username = document.getElementById("username");
        var password = document.getElementById("password");
        if (username == "abc" && password == "abc#123") {
            alert("Login successfully");
            // window.location = "success.html"; // Redirecting to other page.
            // return false;
        } else {
            //attempt --;// Decrementing by one.
            alert("Login failed");
            // Disabling fields after 3 attempts.
            // if( attempt === 0){
            // document.getElementById("username").disabled = true;
            // document.getElementById("password").disabled = true;
            // document.getElementById("submit").disabled = true;
            return false;
        }
    },
});
define("Form1ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_af90f9b4bff548dfba0bb24eec9b13bf: function AS_Button_af90f9b4bff548dfba0bb24eec9b13bf(eventobject) {
        var self = this;
        this.view.Label0aec01eec02244c.text = "success";
    },
    AS_Button_e0a09fadf0e84f1f854c5ebf77746c95: function AS_Button_e0a09fadf0e84f1f854c5ebf77746c95(eventobject) {
        var self = this;
        return self.init.call(this);
    },
    AS_Button_g2e107dd7e1647d3876fc90635b03233: function AS_Button_g2e107dd7e1647d3876fc90635b03233(eventobject) {
        var self = this;
        this.view.Label0cb353593559b48.text = "success";
    }
});
define("Form1Controller", ["userForm1Controller", "Form1ControllerActions"], function() {
    var controller = require("userForm1Controller");
    var controllerActions = ["Form1ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
