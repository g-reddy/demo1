define('applicationController',{
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("com.infinity.onboarding.formElementsTitleCopy1", "formElementsTitleCopy1", "formElementsTitleCopy1Controller");
        kony.application.registerMaster({
            "namespace": "com.infinity.onboarding",
            "classname": "formElementsTitleCopy1",
            "name": "com.infinity.onboarding.formElementsTitleCopy1"
        });
        kony.mvc.registry.add("com.infinity.onboarding.formheaderCopy1", "formheaderCopy1", "formheaderCopy1Controller");
        kony.application.registerMaster({
            "namespace": "com.infinity.onboarding",
            "classname": "formheaderCopy1",
            "name": "com.infinity.onboarding.formheaderCopy1"
        });
        kony.mvc.registry.add("com.infinity.onboarding.sectionheaderCopy1", "sectionheaderCopy1", "sectionheaderCopy1Controller");
        kony.application.registerMaster({
            "namespace": "com.infinity.onboarding",
            "classname": "sectionheaderCopy1",
            "name": "com.infinity.onboarding.sectionheaderCopy1"
        });
        kony.mvc.registry.add("com.infinity.onboarding.sectionsubmitCopy1", "sectionsubmitCopy1", "sectionsubmitCopy1Controller");
        kony.application.registerMaster({
            "namespace": "com.infinity.onboarding",
            "classname": "sectionsubmitCopy1",
            "name": "com.infinity.onboarding.sectionsubmitCopy1"
        });
        kony.mvc.registry.add("flxSampleRowTemplate", "flxSampleRowTemplate", "flxSampleRowTemplateController");
        kony.mvc.registry.add("flxSectionHeaderTemplate", "flxSectionHeaderTemplate", "flxSectionHeaderTemplateController");
        kony.mvc.registry.add("Form1", "Form1", "Form1Controller");
        setAppBehaviors();
    },
    postAppInitCallBack: function(eventObj) {},
    appmenuseq: function() {
        new kony.mvc.Navigation("Form1").navigate();
    }
});

define("com/infinity/onboarding/formElementsTitleCopy1/userformElementsTitleCopy1Controller", [],function() {
    return {};
});
define("com/infinity/onboarding/formElementsTitleCopy1/formElementsTitleCopy1ControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/infinity/onboarding/formElementsTitleCopy1/formElementsTitleCopy1Controller", ["com/infinity/onboarding/formElementsTitleCopy1/userformElementsTitleCopy1Controller", "com/infinity/onboarding/formElementsTitleCopy1/formElementsTitleCopy1ControllerActions"], function() {
    var controller = require("com/infinity/onboarding/formElementsTitleCopy1/userformElementsTitleCopy1Controller");
    var actions = require("com/infinity/onboarding/formElementsTitleCopy1/formElementsTitleCopy1ControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/infinity/onboarding/formElementsTitleCopy1/formElementsTitleCopy1',[],function() {
    return function(controller) {
        var formElementsTitleCopy1 = new kony.ui.FlexContainer(extendConfig({
            "centerX": "50%",
            "clipBounds": true,
            "isMaster": true,
            "height": "20dp",
            "id": "formElementsTitleCopy1",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "90%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 643, 1024, 1200],
            "appName": "demo1"
        }, controller.args[0], "formElementsTitleCopy1"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "formElementsTitleCopy1"), extendConfig({}, controller.args[2], "formElementsTitleCopy1"));
        formElementsTitleCopy1.setDefaultUnit(kony.flex.DP);
        var lblTitle1 = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblTitle1",
            "isVisible": true,
            "left": "10dp",
            "skin": "CopysknLblWidgetTitles1",
            "text": "Enter First Name",
            "top": "0dp",
            "width": "300dp",
            "zIndex": 1
        }, controller.args[0], "lblTitle1"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle1"), extendConfig({}, controller.args[2], "lblTitle1"));
        var lblTitle2 = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblTitle2",
            "isVisible": false,
            "left": "10%",
            "skin": "CopysknLblWidgetTitles1",
            "text": "Label",
            "top": "0dp",
            "width": "300dp",
            "zIndex": 1
        }, controller.args[0], "lblTitle2"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle2"), extendConfig({}, controller.args[2], "lblTitle2"));
        formElementsTitleCopy1.add(lblTitle1, lblTitle2);
        formElementsTitleCopy1.breakpointResetData = {};
        formElementsTitleCopy1.breakpointData = {
            maxBreakpointWidth: 1200,
            "640": {
                "formElementsTitleCopy1": {
                    "segmentProps": [],
                    "isSrcCompTopFlex": true
                }
            },
            "1024": {
                "formElementsTitleCopy1": {
                    "centerX": {
                        "type": "string",
                        "value": "50%"
                    },
                    "height": {
                        "type": "string",
                        "value": "18dp"
                    },
                    "isVisible": true,
                    "top": {
                        "type": "string",
                        "value": "1dp"
                    },
                    "segmentProps": [],
                    "isSrcCompTopFlex": true
                },
                "lblTitle1": {
                    "centerY": {
                        "type": "string",
                        "value": "50%"
                    },
                    "height": {
                        "type": "string",
                        "value": "100%"
                    },
                    "left": {
                        "type": "string",
                        "value": "10dp"
                    },
                    "skin": "CopysknLblWidgetTitles1",
                    "text": "Enter First Name",
                    "top": {
                        "type": "string",
                        "value": "1dp"
                    },
                    "width": {
                        "type": "string",
                        "value": "300dp"
                    },
                    "segmentProps": []
                },
                "lblTitle2": {
                    "centerY": {
                        "type": "string",
                        "value": "50%"
                    },
                    "height": {
                        "type": "string",
                        "value": "100%"
                    },
                    "isVisible": true,
                    "left": {
                        "type": "string",
                        "value": "10%"
                    },
                    "skin": "CopysknLblWidgetTitles1",
                    "text": "Enter Last Name",
                    "top": {
                        "type": "string",
                        "value": "1dp"
                    },
                    "width": {
                        "type": "string",
                        "value": "300dp"
                    },
                    "segmentProps": []
                }
            }
        }
        return formElementsTitleCopy1;
    }
})
;
define("com/infinity/onboarding/formheaderCopy1/userformheaderCopy1Controller", [],function() {
    return {};
});
define("com/infinity/onboarding/formheaderCopy1/formheaderCopy1ControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/infinity/onboarding/formheaderCopy1/formheaderCopy1Controller", ["com/infinity/onboarding/formheaderCopy1/userformheaderCopy1Controller", "com/infinity/onboarding/formheaderCopy1/formheaderCopy1ControllerActions"], function() {
    var controller = require("com/infinity/onboarding/formheaderCopy1/userformheaderCopy1Controller");
    var actions = require("com/infinity/onboarding/formheaderCopy1/formheaderCopy1ControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/infinity/onboarding/formheaderCopy1/formheaderCopy1',[],function() {
    return function(controller) {
        var formheaderCopy1 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "15%",
            "id": "formheaderCopy1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "appName": "demo1"
        }, controller.args[0], "formheaderCopy1"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "formheaderCopy1"), extendConfig({}, controller.args[2], "formheaderCopy1"));
        formheaderCopy1.setDefaultUnit(kony.flex.DP);
        var imgLogo = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgLogo",
            "isVisible": true,
            "skin": "slImage",
            "src": "logo_white_2.png",
            "width": "50%",
            "zIndex": 1
        }, controller.args[0], "imgLogo"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgLogo"), extendConfig({}, controller.args[2], "imgLogo"));
        formheaderCopy1.add(imgLogo);
        return formheaderCopy1;
    }
})
;
define("com/infinity/onboarding/sectionheaderCopy1/usersectionheaderCopy1Controller", [],function() {
    return {};
});
define("com/infinity/onboarding/sectionheaderCopy1/sectionheaderCopy1ControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/infinity/onboarding/sectionheaderCopy1/sectionheaderCopy1Controller", ["com/infinity/onboarding/sectionheaderCopy1/usersectionheaderCopy1Controller", "com/infinity/onboarding/sectionheaderCopy1/sectionheaderCopy1ControllerActions"], function() {
    var controller = require("com/infinity/onboarding/sectionheaderCopy1/usersectionheaderCopy1Controller");
    var actions = require("com/infinity/onboarding/sectionheaderCopy1/sectionheaderCopy1ControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/infinity/onboarding/sectionheaderCopy1/sectionheaderCopy1',[],function() {
    return function(controller) {
        var sectionheaderCopy1 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "15%",
            "id": "sectionheaderCopy1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "appName": "demo1"
        }, controller.args[0], "sectionheaderCopy1"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "sectionheaderCopy1"), extendConfig({}, controller.args[2], "sectionheaderCopy1"));
        sectionheaderCopy1.setDefaultUnit(kony.flex.DP);
        var lblSectionHeader = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblSectionHeader",
            "isVisible": true,
            "left": "5%",
            "skin": "CopysknLblSectionHeader1",
            "text": "Section Header",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblSectionHeader"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSectionHeader"), extendConfig({}, controller.args[2], "lblSectionHeader"));
        var lblStepIndicator = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblStepIndicator",
            "isVisible": true,
            "right": "5%",
            "skin": "CopysknLblSectionHeader1",
            "text": "You are on step 1 of 4",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblStepIndicator"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblStepIndicator"), extendConfig({}, controller.args[2], "lblStepIndicator"));
        sectionheaderCopy1.add(lblSectionHeader, lblStepIndicator);
        return sectionheaderCopy1;
    }
})
;
define("com/infinity/onboarding/sectionsubmitCopy1/usersectionsubmitCopy1Controller", [],function() {
    return {};
});
define("com/infinity/onboarding/sectionsubmitCopy1/sectionsubmitCopy1ControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/infinity/onboarding/sectionsubmitCopy1/sectionsubmitCopy1Controller", ["com/infinity/onboarding/sectionsubmitCopy1/usersectionsubmitCopy1Controller", "com/infinity/onboarding/sectionsubmitCopy1/sectionsubmitCopy1ControllerActions"], function() {
    var controller = require("com/infinity/onboarding/sectionsubmitCopy1/usersectionsubmitCopy1Controller");
    var actions = require("com/infinity/onboarding/sectionsubmitCopy1/sectionsubmitCopy1ControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/infinity/onboarding/sectionsubmitCopy1/sectionsubmitCopy1',[],function() {
    return function(controller) {
        var sectionsubmitCopy1 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "12%",
            "id": "sectionsubmitCopy1",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "appName": "demo1"
        }, controller.args[0], "sectionsubmitCopy1"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "sectionsubmitCopy1"), extendConfig({}, controller.args[2], "sectionsubmitCopy1"));
        sectionsubmitCopy1.setDefaultUnit(kony.flex.DP);
        var btnPrevious = new kony.ui.Button(extendConfig({
            "centerY": "50%",
            "focusSkin": "defBtnFocus",
            "height": "60dp",
            "id": "btnPrevious",
            "isVisible": true,
            "left": "55%",
            "skin": "CopysknCancelPrevious1",
            "text": "Previous",
            "width": "200dp",
            "zIndex": 1
        }, controller.args[0], "btnPrevious"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnPrevious"), extendConfig({}, controller.args[2], "btnPrevious"));
        var btnNext = new kony.ui.Button(extendConfig({
            "centerY": "50%",
            "focusSkin": "defBtnFocus",
            "height": "60dp",
            "id": "btnNext",
            "isVisible": true,
            "left": "25dp",
            "skin": "CopysknSubmitNext1",
            "text": "Next",
            "width": "200dp",
            "zIndex": 1
        }, controller.args[0], "btnNext"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnNext"), extendConfig({}, controller.args[2], "btnNext"));
        sectionsubmitCopy1.add(btnPrevious, btnNext);
        return sectionsubmitCopy1;
    }
})
;
define("flxSampleRowTemplate", [],function() {
    return function(controller) {
        var flxSampleRowTemplate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "75dp",
            "id": "flxSampleRowTemplate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleRowTemplate",
            "width": "100%",
            "appName": "demo1"
        }, {
            "paddingInPixel": false
        }, {});
        flxSampleRowTemplate.setDefaultUnit(kony.flex.DP);
        var lblHeading = new kony.ui.Label({
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknLblRowHeading",
            "text": "Heading",
            "textStyle": {},
            "top": "8.00%",
            "width": "45%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblDescription = new kony.ui.Label({
            "bottom": "10%",
            "id": "lblDescription",
            "isVisible": true,
            "left": "4%",
            "maxNumberOfLines": 3,
            "maxWidth": "70%",
            "skin": "sknLblDescription",
            "text": "Sub-Heading",
            "textStyle": {},
            "textTruncatePosition": constants.TEXT_TRUNCATE_NONE,
            "top": "42%",
            "width": "70%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblTime = new kony.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "right": "9%",
            "skin": "sknLblTimeStamp",
            "text": "Timestamp",
            "textStyle": {},
            "top": "10%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblStrip = new kony.ui.Label({
            "height": "100%",
            "id": "lblStrip",
            "isVisible": true,
            "left": "0dp",
            "maxWidth": "1%",
            "skin": "sknLblStrip",
            "textStyle": {},
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSampleRowTemplate.add(lblHeading, lblDescription, lblTime, lblStrip);
        return flxSampleRowTemplate;
    }
})
;
define("flxSectionHeaderTemplate", [],function() {
    return function(controller) {
        var flxSectionHeaderTemplate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45dp",
            "id": "flxSectionHeaderTemplate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleSectionHeaderTemplate",
            "width": "100%",
            "appName": "demo1"
        }, {
            "paddingInPixel": false
        }, {});
        flxSectionHeaderTemplate.setDefaultUnit(kony.flex.DP);
        var lblHeading = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknSectionHeaderLabelSkin",
            "text": "Heading",
            "textStyle": {},
            "width": "75%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSectionHeaderTemplate.add(lblHeading);
        return flxSectionHeaderTemplate;
    }
})
;
define("userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("flxSampleRowTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSampleRowTemplateController", ["userflxSampleRowTemplateController", "flxSampleRowTemplateControllerActions"], function() {
    var controller = require("userflxSampleRowTemplateController");
    var controllerActions = ["flxSampleRowTemplateControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("flxSectionHeaderTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSectionHeaderTemplateController", ["userflxSectionHeaderTemplateController", "flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("userflxSectionHeaderTemplateController");
    var controllerActions = ["flxSectionHeaderTemplateControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("navigation/NavigationModel", { 
    "Application": {},
    "Forms" : {},
    "UIModules" : {}
});

define("navigation/NavigationController", {
    //Add your navigation controller code here.
});

require(['applicationController','com/infinity/onboarding/formElementsTitleCopy1/formElementsTitleCopy1Controller','com/infinity/onboarding/formElementsTitleCopy1/formElementsTitleCopy1','com/infinity/onboarding/formheaderCopy1/formheaderCopy1Controller','com/infinity/onboarding/formheaderCopy1/formheaderCopy1','com/infinity/onboarding/sectionheaderCopy1/sectionheaderCopy1Controller','com/infinity/onboarding/sectionheaderCopy1/sectionheaderCopy1','com/infinity/onboarding/sectionsubmitCopy1/sectionsubmitCopy1Controller','com/infinity/onboarding/sectionsubmitCopy1/sectionsubmitCopy1','flxSampleRowTemplate','flxSectionHeaderTemplate','flxSampleRowTemplateController','flxSectionHeaderTemplateController','navigation/NavigationModel','navigation/NavigationController'], function(){});

define("sparequirefileslist", function(){});

